package my.Bang;

/**
 *
 * @author Grant Henderson
 */
public class BoneyardCard {
    private int hands;
    
    public BoneyardCard(int hands)
    {
        this.hands = hands;
    }
    public int hands()
    {
        return this.hands;
    }
            
}