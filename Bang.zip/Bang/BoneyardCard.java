package my.Bang;

/**
 *
 * @author ThatP
 */
public class BoneyardCard {
    private int hands;
    
    public BoneyardCard(int hands)
    {
        this.hands = hands;
    }
    public int hands()
    {
        return this.hands;
    }
            
}