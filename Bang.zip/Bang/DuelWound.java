package my.Bang;

/**
 *
 * @author Grant Henderson
 */
public class DuelWound {
    
    private String type;
    
    
    public DuelWound()
    {
        this.type = "";
    }
    public DuelWound(String type)
    {
        this.type = type;
    }
    public String type()
    {
        return this.type;
    }
}