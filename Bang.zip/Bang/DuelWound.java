/* Brady Lowe
    Object oriented Programing Section 1
    R11527629   
    Project 1
 */
package my.Bang;

/**
 *
 * @author ThatP
 */
public class DuelWound {
    
    private String type;
    
    
    public DuelWound()
    {
        this.type = "";
    }
    public DuelWound(String type)
    {
        this.type = type;
    }
    public String type()
    {
        return this.type;
    }
}